function show_value_Income(x)
{
 document.getElementById("slider_value_Income").innerHTML='$'+x;
}
function add_one_Income()
{
  document.getElementById('EstIncome').value=parseInt(document.getElementById('EstIncome').value)+10000;
  show_value_Income(document.getElementById('EstIncome').value);
}
function subtract_one_Income()
{
 document.getElementById('EstIncome').value=parseInt(document.getElementById('EstIncome').value)-10000;
  show_value_Income(document.getElementById('EstIncome').value);
}

function show_value_Age(x)
{
 document.getElementById("slider_value_YearAge").innerHTML=x;
}
function add_one_YearAge()
{
  document.getElementById('Age').value=parseInt(document.getElementById('Age').value)+1;
  show_value_Age(document.getElementById('Age').value);
}
function subtract_one_YearAge()
{
 document.getElementById('Age').value=parseInt(document.getElementById('Age').value)-1;
  show_value_Age(document.getElementById('Age').value);
}

function show_value_LongDistance(x)
{
 document.getElementById("slider_value_LongDistance").innerHTML=x;
}
function add_one_LongDistance()
{
  document.getElementById('LongDistance').value=parseInt(document.getElementById('LongDistance').value)+1;
  show_value_LongDistance(document.getElementById('LongDistance').value);
}
function subtract_one_LongDistance()
{
 document.getElementById('LongDistance').value=parseInt(document.getElementById('LongDistance').value)-1;
  show_value_LongDistance(document.getElementById('LongDistance').value);
}

function show_value_NumberOfChildren(x)
{
 document.getElementById("slider_value_NumberOfChildren").innerHTML=x;
}
function add_one_NumberOfChildren()
{
  document.getElementById('Children').value=parseInt(document.getElementById('Children').value)+1;
  show_value_NumberOfChildren(document.getElementById('Children').value);
}
function subtract_one_NumberOfChildren()
{
 document.getElementById('Children').value=parseInt(document.getElementById('Children').value)-1;
  show_value_NumberOfChildren(document.getElementById('Children').value);
}

function show_value_Dropped(x)
{
 document.getElementById("slider_value_Dropped").innerHTML='$'+x;
}
function add_one_Dropped()
{
  document.getElementById('Dropped').value=parseInt(document.getElementById('Dropped').value)+1;
  show_value_Dropped(document.getElementById('Dropped').value);
}
function subtract_one_Dropped()
{
 document.getElementById('Dropped').value=parseInt(document.getElementById('Dropped').value)-1;
  show_value_Dropped(document.getElementById('Dropped').value);
}

function show_value_LoanAmount(x)
{
 document.getElementById("slider_value_LoanAmount").innerHTML='$'+x;
}
function add_one_LoanAmount()
{
  document.getElementById('LoanAmount').value=parseInt(document.getElementById('LoanAmount').value)+10000;
  show_value_LoanAmount(document.getElementById('LoanAmount').value);
}
function subtract_one_LoanAmount()
{
 document.getElementById('LoanAmount').value=parseInt(document.getElementById('LoanAmount').value)-10000;
  show_value_LoanAmount(document.getElementById('LoanAmount').value);
}

function show_value_SalePrice(x)
{
 document.getElementById("slider_value_SalePrice").innerHTML='$'+x;
}
function add_one_SalePrice()
{
  document.getElementById('SalePrice').value=parseInt(document.getElementById('SalePrice').value)+10000;
  show_value_SalePrice(document.getElementById('SalePrice').value);
}
function subtract_one_SalePrice()
{
 document.getElementById('SalePrice').value=parseInt(document.getElementById('SalePrice').value)-10000;
  show_value_SalePrice(document.getElementById('SalePrice').value);
}

function show_value_International(x)
{
 document.getElementById("slider_value_International").innerHTML=x;
}
function add_one_International()
{
  document.getElementById('International').value=parseInt(document.getElementById('International').value)+1;
  show_value_International(document.getElementById('International').value);
}
function subtract_one_International()
{
 document.getElementById('International').value=parseInt(document.getElementById('International').value)-1;
  show_value_International(document.getElementById('International').value);
}


function show_value_Local(x)
{
 document.getElementById("slider_value_Local").innerHTML=x;
}
function add_one_Local()
{
  document.getElementById('Local').value=parseInt(document.getElementById('Local').value)+1;
  show_value_Local(document.getElementById('Local').value);
}
function subtract_one_Local()
{
 document.getElementById('Local').value=parseInt(document.getElementById('Local').value)-1;
  show_value_Local(document.getElementById('Local').value);
}


